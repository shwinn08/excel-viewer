import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const { currentUser, logout, addClient, getClients, updateClient, deleteClient } = useAuth();
  const [clients, setClients] = useState([]);
  const [newClient, setNewClient] = useState({ email: '', password: '' });
  const [editClient, setEditClient] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchClients = async () => {
      const clientsData = await getClients();
      setClients(clientsData);
    };

    fetchClients();
  }, [getClients]);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const handleAddClient = async (e) => {
    e.preventDefault();
    await addClient(newClient.email, newClient.password);
    const clientsData = await getClients();
    setClients(clientsData);
    setNewClient({ email: '', password: '' });
  };

  const handleEditClient = async (e) => {
    e.preventDefault();
    await updateClient(editClient.id, editClient.email, editClient.password);
    const clientsData = await getClients();
    setClients(clientsData);
    setEditClient(null);
  };

  const handleDeleteClient = async (id) => {
    await deleteClient(id);
    const clientsData = await getClients();
    setClients(clientsData);
  };

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>
      <form onSubmit={editClient ? handleEditClient : handleAddClient} className="admin-form">
        <input
          type="email"
          value={editClient ? editClient.email : newClient.email}
          onChange={(e) => editClient ? setEditClient({ ...editClient, email: e.target.value }) : setNewClient({ ...newClient, email: e.target.value })}
          placeholder="Email"
          required
        />
        <input
          type="password"
          value={editClient ? editClient.password : newClient.password}
          onChange={(e) => editClient ? setEditClient({ ...editClient, password: e.target.value }) : setNewClient({ ...newClient, password: e.target.value })}
          placeholder="Password"
          required
        />
        <button type="submit">{editClient ? 'Update Client' : 'Add Client'}</button>
      </form>
      <ul>
        {clients.map((client) => (
          <li key={client.id}>
            <span>{client.email} - {client.password}</span>
            <button onClick={() => setEditClient(client)}>Edit</button>
            <button onClick={() => handleDeleteClient(client.id)}>Delete</button>
          </li>
        ))}
      </ul>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default AdminDashboard;
