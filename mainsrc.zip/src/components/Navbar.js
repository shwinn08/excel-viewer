import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';


const Navbar = () => {
    const { user, logout } = useContext(AuthContext);

    return (
        <nav>
            <Link to="/">Home</Link>
            {user ? (
                <>
                    {user.role === 'admin' ? (
                        <Link to="/admin">Admin Dashboard</Link>
                    ) : (
                        <Link to="/client">Client Dashboard</Link>
                    )}
                    <button onClick={logout}>Logout</button>
                </>
            ) : (
                <Link to="/login">Login</Link>
            )}
        </nav>
    );
};

export default Navbar;
