// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBFoWvhyP2j4aKCCQNKjB9N0JyYQR7Hw1E",
  authDomain: "excelviewer-b76a9.firebaseapp.com",
  projectId: "excelviewer-b76a9",
  storageBucket: "excelviewer-b76a9.appspot.com",
  messagingSenderId: "14329911663",
  appId: "1:14329911663:web:00f67cdfa6b481bb9c709a",
  measurementId: "G-67MSQJYSZK"
};

// Initialize primary Firebase app
// Initialize primary Firebase app
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Initialize secondary Firebase app for adding clients
const secondaryApp = initializeApp(firebaseConfig, 'Secondary');
const secondaryAuth = getAuth(secondaryApp);

export { auth, db, secondaryAuth };