import React, { useEffect, useState, useRef } from 'react';
import { read, utils } from 'xlsx';
import { useAuth } from '../contexts/AuthContext';
import { doc, getDoc } from 'firebase/firestore';
import { db, storage } from '../firebase';
import { ref, getDownloadURL } from 'firebase/storage';
import './ClientDashboard.css';

const ClientDashboard = () => {
  const [sheets, setSheets] = useState([]);
  const [activeSheetIndex, setActiveSheetIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [originalFileUrl, setOriginalFileUrl] = useState(null);
  const { currentUser, logout } = useAuth();
  const [resultSettings, setResultSettings] = useState({});
  const [results, setResults] = useState([]);
  const [hiddenColumns, setHiddenColumns] = useState({});
  const [workbook, setWorkbook] = useState(null);
  const sheetRef = useRef(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [currentSearchIndex, setCurrentSearchIndex] = useState(-1);
  const [clientFiles, setClientFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);

  useEffect(() => {
    if (!currentUser) {
      setError("No user logged in");
      setLoading(false);
      return;
    }

    const fetchUserData = async () => {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        const userDoc = await getDoc(userDocRef);
    
        if (userDoc.exists()) {
          const userData = userDoc.data();
          if (userData.files && userData.files.length > 0) {
            setClientFiles(userData.files);
          } else {
            setError("No files uploaded for this client");
          }
    
          if (userData.resultSettings) {
            setResultSettings(userData.resultSettings);
            const sortedResults = Object.keys(userData.resultSettings).sort();
            setResults(sortedResults);
          }
        } else {
          setError("User document not found");
        }
        setLoading(false);
      } catch (err) {
        console.error("Error fetching user data:", err);
        setError(`Error loading user data: ${err.message}`);
        setLoading(false);
      }
    };
    
    fetchUserData();
  }, [currentUser]);

  const loadFile = async (fileUrl) => {
    try {
      setLoading(true);
      const proxyUrl = `/proxy${new URL(fileUrl).pathname}${new URL(fileUrl).search}`;
      const response = await fetch(proxyUrl);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const arrayBuffer = await response.arrayBuffer();
      const wb = read(arrayBuffer, { type: 'array', cellStyles: true });
      setWorkbook(wb);

      const parsedSheets = wb.SheetNames.map((sheetName) => {
        return {
          name: sheetName,
          data: utils.sheet_to_json(wb.Sheets[sheetName], { header: 1 }),
        };
      });

      setSheets(parsedSheets);
      setActiveSheetIndex(0);
      setLoading(false);
    } catch (err) {
      console.error("Error loading file:", err);
      setError(`Error loading file: ${err.message}`);
      setLoading(false);
    }
  };

  const handleSheetChange = (index) => {
    setActiveSheetIndex(index);
    setHiddenColumns({});
    setSearchQuery('');
    setSearchResults([]);
    setCurrentSearchIndex(-1);
  };

  const downloadExcel = async () => {
    if (selectedFile) {
      try {
        const fileRef = ref(storage, selectedFile.url);
        const downloadURL = await getDownloadURL(fileRef);
        
        const link = document.createElement('a');
        link.href = downloadURL;
        link.download = selectedFile.originalName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        console.error("Error downloading file:", error);
      }
    } else {
      console.error("No file selected");
    }
  };

  const applyResultHiddenColumns = (result) => {
    const resultSetting = resultSettings[result];
    if (resultSetting && resultSetting.hiddenColumns && resultSetting.sheetName) {
      const sheetIndex = sheets.findIndex(sheet => sheet.name === resultSetting.sheetName);
      if (sheetIndex !== -1) {
        setActiveSheetIndex(sheetIndex);
        const columnsToHide = resultSetting.hiddenColumns.split(',').map(num => parseInt(num.trim()) - 1);
        const newHiddenColumns = {};
        columnsToHide.forEach(colIndex => {
          newHiddenColumns[colIndex] = true;
        });
        setHiddenColumns(newHiddenColumns);
      }
    }
  };

  const showAllColumns = () => {
    setHiddenColumns({});
  };

  const applyHiddenColumns = () => {
    if (!sheetRef.current) return;

    const rows = sheetRef.current.querySelectorAll('tr');
    rows.forEach(row => {
      const cells = row.querySelectorAll('td, th');
      cells.forEach((cell, index) => {
        if (hiddenColumns[index]) {
          cell.style.display = 'none';
        } else {
          cell.style.display = '';
        }
      });
    });
  };

  const applyResizableColumns = () => {
    if (!sheetRef.current) return;

    const table = sheetRef.current.querySelector('table');
    if (!table) return;

    const headerRow = table.querySelector('tr');
    const headers = headerRow.querySelectorAll('th');
    headers.forEach((header, index) => {
      if (index < headers.length - 1) {
        const resizer = document.createElement('div');
        resizer.className = 'column-resizer';
        header.appendChild(resizer);
        resizer.addEventListener('mousedown', startColumnResize);
      }
    });

    const rows = table.querySelectorAll('tr');
    rows.forEach((row, index) => {
      if (index < rows.length - 1) {
        const resizer = document.createElement('div');
        resizer.className = 'row-resizer';
        row.appendChild(resizer);
        resizer.addEventListener('mousedown', startRowResize);
      }
    });
  };

  const startColumnResize = (e) => {
    const th = e.target.parentElement;
    const startX = e.pageX;
    const startWidth = th.offsetWidth;

    const mousemove = (e) => {
      const width = startWidth + e.pageX - startX;
      th.style.width = `${width}px`;
    };

    const mouseup = () => {
      document.removeEventListener('mousemove', mousemove);
      document.removeEventListener('mouseup', mouseup);
    };

    document.addEventListener('mousemove', mousemove);
    document.addEventListener('mouseup', mouseup);
  };

  const startRowResize = (e) => {
    const tr = e.target.parentElement;
    const startY = e.pageY;
    const startHeight = tr.offsetHeight;

    const mousemove = (e) => {
      const height = startHeight + e.pageY - startY;
      tr.style.height = `${height}px`;
    };

    const mouseup = () => {
      document.removeEventListener('mousemove', mousemove);
      document.removeEventListener('mouseup', mouseup);
    };

    document.addEventListener('mousemove', mousemove);
    document.addEventListener('mouseup', mouseup);
  };

  const renderSheetContent = () => {
    if (!workbook || !sheets[activeSheetIndex]) return null;

    const sheet = workbook.Sheets[sheets[activeSheetIndex].name];
    const html = utils.sheet_to_html(sheet, {
      editable: false,
      display: {
        showHeaders: true,
        sheetFormat: { defaultColWidth: 120, defaultRowHeight: 20 }
      }
    });

    return (
      <div 
        className="sheet-container" 
        ref={sheetRef}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  };

  const handleSearch = () => {
    if (!sheetRef.current || !searchQuery) {
      setSearchResults([]);
      setCurrentSearchIndex(-1);
      return;
    }
  
    const cells = sheetRef.current.querySelectorAll('td, th');
    const newResults = [];
  
    cells.forEach((cell, index) => {
      const text = cell.textContent.toLowerCase();
      if (text.includes(searchQuery.toLowerCase())) {
        newResults.push({ element: cell, index });
      }
    });
  
    setSearchResults(newResults);
    setCurrentSearchIndex(newResults.length > 0 ? 0 : -1);
    highlightSearchResult(newResults[0]?.element);
  };

  const highlightSearchResult = (element) => {
    const highlights = sheetRef.current.querySelectorAll('.search-highlight');
    highlights.forEach(el => el.classList.remove('search-highlight'));
  
    if (element) {
      const text = element.textContent.toLowerCase();
      const searchText = searchQuery.toLowerCase();
      const startIndex = text.indexOf(searchText);
      if (startIndex !== -1) {
        const before = element.textContent.substring(0, startIndex);
        const match = element.textContent.substring(startIndex, startIndex + searchText.length);
        const after = element.textContent.substring(startIndex + searchText.length);
        element.innerHTML = before + '<span class="search-highlight">' + match + '</span>' + after;
      }
  
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const handleNextResult = () => {
    if (searchResults.length === 0) return;
  
    const nextIndex = (currentSearchIndex + 1) % searchResults.length;
    setCurrentSearchIndex(nextIndex);
    highlightSearchResult(searchResults[nextIndex].element);
  };
  
  const handlePreviousResult = () => {
    if (searchResults.length === 0) return;
  
    const prevIndex = (currentSearchIndex - 1 + searchResults.length) % searchResults.length;
    setCurrentSearchIndex(prevIndex);
    highlightSearchResult(searchResults[prevIndex].element);
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (error) {
    return <div className="error">Error: {error}</div>;
  }

  return (
    <div className="App">
      <button className="logout" onClick={logout}>Logout</button>
      <h1>Welcome to Your Dashboard</h1>
      {!selectedFile ? (
        <div className="file-selection">
          <h2>Select a file to view:</h2>
          {clientFiles.map((file, index) => (
            <button key={index} onClick={() => {
              setSelectedFile(file);
              loadFile(file.url);
            }}>
              {file.name}
            </button>
          ))}
        </div>
      ) : (
        <>
          <button className="download" onClick={downloadExcel}>Download Excel</button>
          {sheets.length > 0 && (
            <div className="excel-viewer">
              <div className="dropdown">
                <button className="dropbtn">Select Sheet</button>
                <div className="dropdown-content">
                  {sheets.map((sheet, index) => (
                    <a key={index} onClick={() => handleSheetChange(index)}>
                      {sheet.name}
                    </a>
                  ))}
                </div>
              </div>
              <div className="nav">
                {sheets.map((sheet, index) => (
                  <button
                    key={index}
                    className={index === activeSheetIndex ? 'active' : ''}
                    onClick={() => handleSheetChange(index)}
                  >
                    {sheet.name}
                  </button>
                ))}
              </div>
              <div className="search-bar">
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    handleSearch();
                  }}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
                <button onClick={handleSearch}>Search</button>
                <button onClick={handlePreviousResult} disabled={searchResults.length === 0}>Previous</button>
                <button onClick={handleNextResult} disabled={searchResults.length === 0}>Next</button>
                <span>{searchResults.length > 0 ? `${currentSearchIndex + 1}/${searchResults.length}` : '0/0'}</span>
              </div>
              <div className="result-buttons">
                {results.map((result, index) => (
                  <button key={index} onClick={() => applyResultHiddenColumns(result)}>
                    Result {result.toUpperCase()}
                  </button>
                ))}
                <button onClick={showAllColumns}>Show All Columns</button>
              </div>
              {renderSheetContent()}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ClientDashboard;