import React, { useEffect, useRef } from 'react';
import html2canvas from 'html2canvas';
import { utils } from 'xlsx';

const ExcelRenderer = ({ workbook, activeSheetIndex }) => {
  const containerRef = useRef(null);

  useEffect(() => {
    if (workbook) {
      const sheet = workbook.Sheets[workbook.SheetNames[activeSheetIndex]];
      const htmlString = utils.sheet_to_html(sheet, { id: 'excel-sheet', editable: false });
      const container = containerRef.current;
      container.innerHTML = htmlString;
    }
  }, [workbook, activeSheetIndex]);

  useEffect(() => {
    const renderImage = async () => {
      const container = containerRef.current;
      if (container) {
        const canvas = await html2canvas(container);
        const img = canvas.toDataURL('image/png');
        const imgElement = new Image();
        imgElement.src = img;
        container.innerHTML = '';
        container.appendChild(imgElement);
      }
    };

    renderImage();
  }, [workbook, activeSheetIndex]);

  return <div ref={containerRef}></div>;
};

export default ExcelRenderer;
