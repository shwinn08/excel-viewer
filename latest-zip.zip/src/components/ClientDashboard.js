import React, { useEffect, useState } from 'react';
import { read, utils } from 'xlsx';
import { useAuth } from '../contexts/AuthContext';
import { doc, getDoc } from 'firebase/firestore';
import { db, storage } from '../firebase';
import { ref, getDownloadURL } from 'firebase/storage';
import './ClientDashboard.css';
import { Resizable } from 're-resizable';

const ClientDashboard = () => {
  const [sheets, setSheets] = useState([]);
  const [activeSheetIndex, setActiveSheetIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [columnWidths, setColumnWidths] = useState({});
  const [rowHeights, setRowHeights] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedRows, setExpandedRows] = useState({});
  const [originalFileUrl, setOriginalFileUrl] = useState(null);
  const { currentUser, logout } = useAuth();
  const [resultSettings, setResultSettings] = useState({});
  const [results, setResults] = useState([]);
  const [mergedCells, setMergedCells] = useState([]);
  const [hiddenColumns, setHiddenColumns] = useState({});

  useEffect(() => {
    if (!currentUser) {
      setError("No user logged in");
      setLoading(false);
      return;
    }

    const fetchFile = async () => {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        const userDoc = await getDoc(userDocRef);
    
        if (userDoc.exists()) {
          const userData = userDoc.data();
          if (userData.fileUrl) {
            setOriginalFileUrl(userData.fileUrl);
            const proxyUrl = `/proxy${new URL(userData.fileUrl).pathname}${new URL(userData.fileUrl).search}`;
            const response = await fetch(proxyUrl);
            if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
            }
            const arrayBuffer = await response.arrayBuffer();
            const workbook = read(arrayBuffer, { type: 'array' });
    
            const parsedSheets = workbook.SheetNames.map((sheetName) => {
              const sheet = workbook.Sheets[sheetName];
              return {
                name: sheetName,
                data: utils.sheet_to_json(sheet, { header: 1 }),
                html: sheet,
                merges: sheet['!merges'] || [],
              };
            });
    
            setSheets(parsedSheets);
            setLoading(false);
          } else {
            setError("No file uploaded for this client");
            setLoading(false);
          }
    
          if (userData.resultSettings) {
            setResultSettings(userData.resultSettings);
            const sortedResults = Object.keys(userData.resultSettings).sort();
            setResults(sortedResults);
          }
        } else {
          setError("User document not found");
          setLoading(false);
        }
      } catch (err) {
        console.error("Error fetching file:", err);
        setError(`Error loading file: ${err.message}`);
        setLoading(false);
      }
    };
    
    fetchFile();
  }, [currentUser]);

  const handleSheetChange = (index) => {
    setActiveSheetIndex(index);
    setSearchQuery('');
    setExpandedRows({});
    setHiddenColumns({});
  };

  const handleSearch = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
  };

  const handleColumnResize = (index, width) => {
    setColumnWidths((prevWidths) => ({
      ...prevWidths,
      [index]: width,
    }));
  };

  const handleRowResize = (index, height) => {
    setRowHeights((prevHeights) => ({
      ...prevHeights,
      [index]: height,
    }));
  };

  const toggleRowExpansion = (rowIndex) => {
    setExpandedRows((prevExpanded) => ({
      ...prevExpanded,
      [rowIndex]: !prevExpanded[rowIndex],
    }));
  };

  const downloadExcel = async () => {
    if (originalFileUrl) {
      try {
        const fileRef = ref(storage, originalFileUrl);
        const downloadURL = await getDownloadURL(fileRef);
        
        const link = document.createElement('a');
        link.href = downloadURL;
        link.download = 'original_file.xlsx';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        console.error("Error downloading file:", error);
      }
    } else {
      console.error("No original file URL available");
    }
  };

  const applyResultHiddenColumns = (result) => {
    const resultSetting = resultSettings[result];
    if (resultSetting && resultSetting.hiddenColumns && resultSetting.sheetName) {
      const sheetIndex = sheets.findIndex(sheet => sheet.name === resultSetting.sheetName);
      if (sheetIndex !== -1) {
        setActiveSheetIndex(sheetIndex);
        const columnsToHide = resultSetting.hiddenColumns.split(',').map(num => parseInt(num.trim()) - 1);
        const newHiddenColumns = {};
        columnsToHide.forEach(colIndex => {
          newHiddenColumns[colIndex] = true;
        });
        setHiddenColumns(newHiddenColumns);
      }
    }
  };

  const showAllColumns = () => {
    setHiddenColumns({});
  };

  const activeSheet = sheets[activeSheetIndex];
  
  const filteredRows = activeSheet
    ? activeSheet.data.slice(1).filter((row) =>
        row.some((cell) => cell.toString().toLowerCase().includes(searchQuery))
      )
    : [];

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (error) {
    return <div className="error">Error: {error}</div>;
  }

  return (
    <div className="App">
      <button className="logout" onClick={logout}>Logout</button>
      <button className="download" onClick={downloadExcel}>Download Excel</button>
      {sheets.length > 0 ? (
        <div className="excel-viewer">
          <div className="dropdown">
            <button className="dropbtn">Select Sheet</button>
            <div className="dropdown-content">
              {sheets.map((sheet, index) => (
                <a key={index} onClick={() => handleSheetChange(index)}>
                  {sheet.name}
                </a>
              ))}
            </div>
          </div>
          <div className="nav">
            {sheets.map((sheet, index) => (
              <button
                key={index}
                className={index === activeSheetIndex ? 'active' : ''}
                onClick={() => handleSheetChange(index)}
              >
                {sheet.name}
              </button>
            ))}
          </div>
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={handleSearch}
            />
          </div>
          <div className="result-buttons">
            {results.map((result, index) => (
              <button key={index} onClick={() => applyResultHiddenColumns(result)}>
                Result {result.toUpperCase()}
              </button>
            ))}
            <button onClick={showAllColumns}>Show All Columns</button>
          </div>
          <div className="sheet-container">
            <table className="sheet">
              <thead>
                <tr>
                  {activeSheet.data[0].map((header, index) => (
                    !hiddenColumns[index] && (
                      <th key={index}>
                        <Resizable
                          width={columnWidths[index] || 'auto'}
                          height="auto"
                          onResizeStop={(e, direction, ref, d) => handleColumnResize(index, ref.style.width)}
                          enable={{ right: true, left: true }}
                        >
                          {header}
                        </Resizable>
                      </th>
                    )
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((row, rowIndex) => (
                  <React.Fragment key={rowIndex}>
                    <tr>
                      {row.map((cell, cellIndex) => (
                        !hiddenColumns[cellIndex] && (
                          <td key={cellIndex}>
                            <Resizable
                              width={columnWidths[cellIndex] || 'auto'}
                              height={rowHeights[rowIndex] || 'auto'}
                              onResizeStop={(e, direction, ref, d) => {
                                handleRowResize(rowIndex, ref.style.height);
                                handleColumnResize(cellIndex, ref.style.width);
                              }}
                              enable={{ bottom: true, right: true, left: true }}
                            >
                              {cellIndex === 0 ? (
                                <button onClick={() => toggleRowExpansion(rowIndex)}>
                                  {expandedRows[rowIndex] ? '−' : '+'}
                                </button>
                              ) : null}
                              {cell}
                            </Resizable>
                          </td>
                        )
                      ))}
                    </tr>
                    {expandedRows[rowIndex] && (
                      <tr className="expanded-row">
                        <td colSpan={row.length}>
                          <div className="expanded-content">
                            {row.map((cell, cellIndex) => (
                              !hiddenColumns[cellIndex] && (
                                <p key={cellIndex}><strong>{activeSheet.data[0][cellIndex]}:</strong> {cell}</p>
                              )
                            ))}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="no-file">No file uploaded for this client</div>
      )}
    </div>
  );
};

export default ClientDashboard;
