import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const { currentUser, logout, addClient, getClients, updateClient, deleteClient, uploadClientFile } = useAuth();
  const [clients, setClients] = useState([]);
  const [newClient, setNewClient] = useState({ email: '', password: '' });
  const [editClient, setEditClient] = useState(null);
  const [files, setFiles] = useState({});
  const [uploadStatus, setUploadStatus] = useState({});
  const [filePreview, setFilePreview] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const clientsData = await getClients();
        setClients(clientsData);
      } catch (error) {
        console.error("Error fetching clients:", error);
      }
    };

    fetchClients();
  }, [getClients]);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const handleAddClient = async (e) => {
    e.preventDefault();
    try {
      await addClient(newClient.email, newClient.password);
      const clientsData = await getClients();
      setClients(clientsData);
      setNewClient({ email: '', password: '' });
    } catch (error) {
      console.error("Error adding client:", error);
    }
  };

  const handleEditClient = async (e) => {
    e.preventDefault();
    try {
      await updateClient(editClient.id, editClient.email, editClient.newPassword);
      const clientsData = await getClients();
      setClients(clientsData);
      setEditClient(null);
    } catch (error) {
      console.error("Error updating client:", error);
    }
  };

  const handleDeleteClient = async (id) => {
    try {
      await deleteClient(id);
      const clientsData = await getClients();
      setClients(clientsData);
    } catch (error) {
      console.error("Error deleting client:", error);
    }
  };

  const handleFileChange = (e, clientId) => {
    const file = e.target.files[0];
    setFiles({ ...files, [clientId]: file });
    
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFilePreview({ ...filePreview, [clientId]: e.target.result });
      };
      if (file.type.startsWith('image/')) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    }
  };

  const handleUpload = async (clientId) => {
    if (!files[clientId]) {
      setUploadStatus({ ...uploadStatus, [clientId]: 'Please select a file.' });
      return;
    }

    try {
      setUploadStatus({ ...uploadStatus, [clientId]: 'Uploading...' });
      const fileUrl = await uploadClientFile(clientId, files[clientId]);
      setUploadStatus({ ...uploadStatus, [clientId]: 'File uploaded successfully!' });

      setClients(prevClients => 
        prevClients.map(client => 
          client.id === clientId ? { ...client, fileUrl, fileName: files[clientId].name } : client
        )
      );

      setFiles({ ...files, [clientId]: null });
      setFilePreview({ ...filePreview, [clientId]: null });
    } catch (error) {
      console.error('Error uploading file:', error);
      setUploadStatus({ ...uploadStatus, [clientId]: `File upload failed: ${error.message}` });
    }
  };

  const renderFilePreview = (clientId) => {
    const file = files[clientId];
    if (!file) return null;

    if (file.type.startsWith('image/')) {
      return <img src={filePreview[clientId]} alt="File preview" className="preview-image" />;
    } else {
      return <div className="file-name-preview">{file.name}</div>;
    }
  };

  return (
    <div className="admin-dashboard">
      <header className="dashboard-header">
        <h1>Admin Dashboard</h1>
        <button onClick={handleLogout} className="logout-btn">Logout</button>
      </header>
      <main className="dashboard-content">
        <section className="client-form-section">
          <h2>{editClient ? 'Edit Client' : 'Add New Client'}</h2>
          <form onSubmit={editClient ? handleEditClient : handleAddClient} className="admin-form">
            <input
              type="email"
              value={editClient ? editClient.email : newClient.email}
              onChange={(e) => editClient ? setEditClient({ ...editClient, email: e.target.value }) : setNewClient({ ...newClient, email: e.target.value })}
              placeholder="Email"
              required
            />
            <input
              type="password"
              value={editClient ? editClient.newPassword || '' : newClient.password}
              onChange={(e) => editClient ? setEditClient({ ...editClient, newPassword: e.target.value }) : setNewClient({ ...newClient, password: e.target.value })}
              placeholder={editClient ? "New Password (leave blank to keep current)" : "Password"}
              required={!editClient}
            />
            <button type="submit" className="submit-btn">{editClient ? 'Update Client' : 'Add Client'}</button>
            {editClient && <button type="button" onClick={() => setEditClient(null)} className="cancel-btn">Cancel Edit</button>}
          </form>
        </section>
        <section className="client-list-section">
          <h2>Client List</h2>
          <ul className="client-list">
            {clients.map((client) => (
              <li key={client.id} className="client-item">
                <div className="client-info">
                  <span className="client-email">Email: {client.email}</span>
                  <span className="client-password">Password: {client.currentPassword || 'N/A'}</span>
                  <div className="client-actions">
                    <button onClick={() => setEditClient(client)} className="edit-btn">Edit</button>
                    <button onClick={() => handleDeleteClient(client.id)} className="delete-btn">Delete</button>
                  </div>
                </div>
                <div className="file-upload-section">
                  <input 
                    type="file" 
                    onChange={(e) => handleFileChange(e, client.id)} 
                    className="file-input"
                    id={`file-${client.id}`}
                  />
                  <label htmlFor={`file-${client.id}`} className="file-label">Choose File</label>
                  {files[client.id] && (
                    <div className="file-preview">
                      {renderFilePreview(client.id)}
                      <button 
                        onClick={() => handleUpload(client.id)}
                        disabled={uploadStatus[client.id] === 'Uploading...'}
                        className="upload-btn"
                      >
                        Confirm Upload
                      </button>
                    </div>
                  )}
                  {client.fileUrl && (
                    <div className="file-status">
                      <span>File uploaded: {client.fileName}</span>
                    </div>
                  )}
                  <p className="upload-status">{uploadStatus[client.id]}</p>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
};

export default AdminDashboard;