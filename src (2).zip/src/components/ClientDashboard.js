import React, { useEffect, useState } from 'react';
import { read, utils, write } from 'xlsx';
import { useAuth } from '../contexts/AuthContext';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import './ClientDashboard.css';
import { Resizable } from 're-resizable';

const ClientDashboard = () => {
  const [sheets, setSheets] = useState([]);
  const [activeSheetIndex, setActiveSheetIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [columnWidths, setColumnWidths] = useState({});
  const [rowHeights, setRowHeights] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedRows, setExpandedRows] = useState({});
  const [originalFile, setOriginalFile] = useState(null);
  const { currentUser, logout } = useAuth();

  useEffect(() => {
    if (!currentUser) {
      setError("No user logged in");
      setLoading(false);
      return;
    }

    const fetchFile = async () => {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        const userDoc = await getDoc(userDocRef);

        if (userDoc.exists()) {
          const userData = userDoc.data();
          if (userData.fileUrl) {
            const proxyUrl = `/proxy${new URL(userData.fileUrl).pathname}${new URL(userData.fileUrl).search}`;
            const response = await fetch(proxyUrl);
            if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
            }
            const arrayBuffer = await response.arrayBuffer();
            setOriginalFile(arrayBuffer);
            const workbook = read(arrayBuffer, { type: 'array' });

            const parsedSheets = workbook.SheetNames.map((sheetName) => ({
              name: sheetName,
              data: utils.sheet_to_json(workbook.Sheets[sheetName], { header: 1 }),
            }));

            setSheets(parsedSheets);
            setLoading(false);
          } else {
            setError("No file uploaded for this client");
            setLoading(false);
          }
        } else {
          setError("User document not found");
          setLoading(false);
        }
      } catch (err) {
        console.error("Error fetching file:", err);
        setError(`Error loading file: ${err.message}`);
        setLoading(false);
      }
    };

    fetchFile();
  }, [currentUser]);

  const handleSheetChange = (index) => {
    setActiveSheetIndex(index);
    setSearchQuery('');
    setExpandedRows({});
  };

  const handleSearch = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
  };

  const handleColumnResize = (index, width) => {
    setColumnWidths((prevWidths) => ({
      ...prevWidths,
      [index]: width,
    }));
  };

  const handleRowResize = (index, height) => {
    setRowHeights((prevHeights) => ({
      ...prevHeights,
      [index]: height,
    }));
  };

  const toggleRowExpansion = (rowIndex) => {
    setExpandedRows((prevExpanded) => ({
      ...prevExpanded,
      [rowIndex]: !prevExpanded[rowIndex],
    }));
  };

  const downloadExcel = () => {
    if (originalFile) {
      const blob = new Blob([originalFile], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'original_file.xlsx';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const activeSheet = sheets[activeSheetIndex];
  
  const filteredRows = activeSheet
    ? activeSheet.data.slice(1).filter((row) =>
        row.some((cell) => cell.toString().toLowerCase().includes(searchQuery))
      )
    : [];

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (error) {
    return <div className="error">Error: {error}</div>;
  }

  return (
    <div className="App">
      <button className="logout" onClick={logout}>Logout</button>
      <button className="download" onClick={downloadExcel}>Download Excel</button>
      {sheets.length > 0 ? (
        <div className="excel-viewer">
          <div className="dropdown">
            <button className="dropbtn">Select Sheet</button>
            <div className="dropdown-content">
              {sheets.map((sheet, index) => (
                <a key={index} onClick={() => handleSheetChange(index)}>
                  {sheet.name}
                </a>
              ))}
            </div>
          </div>
          <div className="nav">
            {sheets.map((sheet, index) => (
              <button
                key={index}
                className={index === activeSheetIndex ? 'active' : ''}
                onClick={() => handleSheetChange(index)}
              >
                {sheet.name}
              </button>
            ))}
          </div>
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={handleSearch}
            />
          </div>
          <div className="sheet-container">
            <table className="sheet">
              <thead>
                <tr>
                  {activeSheet.data[0].map((header, index) => (
                    <th key={index}>
                      <Resizable
                        width={columnWidths[index] || 'auto'}
                        height="auto"
                        onResizeStop={(e, direction, ref, d) => handleColumnResize(index, ref.style.width)}
                        enable={{ right: true }}
                      >
                        {header}
                      </Resizable>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((row, rowIndex) => (
                  <React.Fragment key={rowIndex}>
                    <tr>
                      {row.map((cell, cellIndex) => (
                        <td key={cellIndex}>
                          <Resizable
                            width="auto"
                            height={rowHeights[rowIndex] || 'auto'}
                            onResizeStop={(e, direction, ref, d) => handleRowResize(rowIndex, ref.style.height)}
                            enable={{ bottom: true }}
                          >
                            {cellIndex === 0 ? (
                              <button onClick={() => toggleRowExpansion(rowIndex)}>
                                {expandedRows[rowIndex] ? '−' : '+'}
                              </button>
                            ) : null}
                            {cell}
                          </Resizable>
                        </td>
                      ))}
                    </tr>
                    {expandedRows[rowIndex] && (
                      <tr className="expanded-row">
                        <td colSpan={row.length}>
                          <div className="expanded-content">
                            {row.map((cell, cellIndex) => (
                              <p key={cellIndex}><strong>{activeSheet.data[0][cellIndex]}:</strong> {cell}</p>
                            ))}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div>No data available</div>
      )}
    </div>
  );
};

export default ClientDashboard;