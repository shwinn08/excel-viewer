// FilePreviewModal.js
import React, { useEffect, useState } from 'react';
import * as XLSX from 'xlsx';
import './FilePreviewModal.css';

const FilePreviewModal = ({ fileData, onClose }) => {
  const [workbook, setWorkbook] = useState(null);
  const [selectedSheet, setSelectedSheet] = useState(null);

  useEffect(() => {
    if (fileData) {
      const workbook = XLSX.read(new Uint8Array(fileData), { type: 'array' });
      setWorkbook(workbook);
      setSelectedSheet(workbook.SheetNames[0]);
    }
  }, [fileData]);

  const renderSheetPreview = (sheetName) => {
    const sheet = workbook.Sheets[sheetName];
    const range = XLSX.utils.decode_range(sheet['!ref']);
    const rows = [];

    for (let rowNum = range.s.r; rowNum <= range.e.r; rowNum++) {
      const row = [];
      for (let colNum = range.s.c; colNum <= range.e.c; colNum++) {
        const cell = sheet[XLSX.utils.encode_cell({ r: rowNum, c: colNum })];
        row.push(cell ? cell.v : '');
      }
      rows.push(row);
    }

    return (
      <table className="preview-table">
        <thead>
          <tr>
            {rows[0].map((cell, i) => <th key={i}>{cell}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.slice(1).map((row, i) => (
            <tr key={i}>
              {row.map((cell, j) => <td key={j}>{cell}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button onClick={onClose} className="close-btn">&times;</button>
        {workbook && (
          <div>
            <div className="sheet-tabs">
              {workbook.SheetNames.map((name) => (
                <button
                  key={name}
                  className={`sheet-tab ${selectedSheet === name ? 'active' : ''}`}
                  onClick={() => setSelectedSheet(name)}
                >
                  {name}
                </button>
              ))}
            </div>
            {selectedSheet && renderSheetPreview(selectedSheet)}
            <div className="download-btn-container">
              <a href={URL.createObjectURL(new Blob([fileData]))} download="file.xlsx" className="download-btn">Download Original File</a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FilePreviewModal;
