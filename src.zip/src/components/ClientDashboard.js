import { read, utils } from 'xlsx';
import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Resizable } from 'react-resizable';
import file from './data.xlsx';
import './ClientDashboard.css';



const ClientDashboard = () => {
  const [sheets, setSheets] = useState([]);
  const [activeSheetIndex, setActiveSheetIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [columnWidths, setColumnWidths] = useState({});
  const [rowHeights, setRowHeights] = useState({});

  useEffect(() => {
    fetch(file)
      .then((response) => response.arrayBuffer())
      .then((data) => {
        const workbook = read(data, { type: 'array' });
        const parsedSheets = workbook.SheetNames.map((sheetName) => ({
          name: sheetName,
          data: utils.sheet_to_json(workbook.Sheets[sheetName], { header: 1 }),
        }));

        setSheets(parsedSheets);
      })
      .catch((err) => console.log(err));
  }, []);

  const handleSheetChange = (index) => {
    setActiveSheetIndex(index);
    setSearchQuery('');
    setColumnWidths({});
    setRowHeights({});
  };

  const handleSearch = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
  };

  const handleResize = (index, direction, size) => {
    if (direction === 'column') {
      setColumnWidths({ ...columnWidths, [index]: size.width });
    } else if (direction === 'row') {
      setRowHeights({ ...rowHeights, [index]: size.height });
    }
  };

  const activeSheet = sheets[activeSheetIndex];
  const filteredRows = activeSheet
    ? activeSheet.data.slice(1).filter((row) =>
        row.some((cell) => cell.toString().toLowerCase().includes(searchQuery))
      )
    : [];

  return (
    <div className="App">
      {sheets.length > 0 ? (
        <div className="excel-viewer">
          <div className="nav">
            {sheets.map((sheet, index) => (
              <button
                key={index}
                className={index === activeSheetIndex ? 'active' : ''}
                onClick={() => handleSheetChange(index)}
              >
                {sheet.name}
              </button>
            ))}
          </div>
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={handleSearch}
            />
          </div>
          <div className="sheet-container">
            <table className="sheet">
              <thead>
                <tr>
                  {activeSheet.data[0].map((header, index) => (
                    <Resizable
                      key={index}
                      width={columnWidths[index] || 100}
                      height={50}
                      onResize={(e, { size }) =>
                        handleResize(index, 'column', size)
                      }
                    >
                      <th style={{ width: columnWidths[index] || 100 }}>
                        {header}
                      </th>
                    </Resizable>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((row, rowIndex) => (
                  <Resizable
                    key={rowIndex}
                    width={100}
                    height={rowHeights[rowIndex] || 50}
                    onResize={(e, { size }) =>
                      handleResize(rowIndex, 'row', size)
                    }
                  >
                    <tr style={{ height: rowHeights[rowIndex] || 50 }}>
                      {row.map((cell, cellIndex) => (
                        <td
                          key={cellIndex}
                          style={{ width: columnWidths[cellIndex] || 100 }}
                        >
                          {cell}
                        </td>
                      ))}
                    </tr>
                  </Resizable>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div>Loading...</div>
      )}
    </div>
  );

};

export default ClientDashboard;
